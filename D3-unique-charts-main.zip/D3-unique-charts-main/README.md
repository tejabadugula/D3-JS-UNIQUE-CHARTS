# D3-unique-charts
1.ANIMATED DENTOGRAM + BAR CHART 
It explaines the This graph displays the money spent by people in each year

After executing the code in d3.js

1.Click in any year on the graph to show the money spent by that persons in that year which will be displayed on bar chart 2. Click on the any person to get the years in which the money he spent

2.ANIMATED LINE CHART FOR STOCK MARKET PREDICTION
It shows the historical stock market prices in animation line chart and also predicts the future stock prices in line plot
1.Below it shows the months where u can selects the months in which u want to line plot in the chart
